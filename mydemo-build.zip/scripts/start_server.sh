
#!/bin/bash
systemctl start tomcat
