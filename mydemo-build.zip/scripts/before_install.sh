#!/bin/bash
rm -rf /usr/share/tomcat/webapps/mydemo*
